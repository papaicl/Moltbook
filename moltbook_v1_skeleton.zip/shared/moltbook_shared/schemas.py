from __future__ import annotations

from typing import Any, Literal, Optional
from pydantic import BaseModel, Field


TaskStatus = Literal["planned", "running", "completed", "failed"]
StepStatus = Literal["planned", "running", "completed", "failed"]


class Constraints(BaseModel):
    max_cost_usd: float = 5.0
    max_runtime_sec: int = 600


class ProjectCreate(BaseModel):
    name: str
    type: Literal["web_app", "report", "data_job", "mixed"]
    template: Optional[str] = None


class ProjectOut(BaseModel):
    project_id: str
    name: str
    type: str
    template: Optional[str] = None


class PlanTaskIn(BaseModel):
    project_id: str
    prompt: str
    constraints: Constraints = Field(default_factory=Constraints)


class PlannedStep(BaseModel):
    step_id: str
    tool: str
    description: str
    input_payload: dict[str, Any] = Field(default_factory=dict)


class PlanTaskOut(BaseModel):
    task_id: str
    steps: list[PlannedStep]
    estimated_cost_usd: float


class ExecuteTaskIn(BaseModel):
    task_id: str


class ToolCallResult(BaseModel):
    status: Literal["success", "failed"]
    output_payload: dict[str, Any] = Field(default_factory=dict)
    artifact_refs: list[dict[str, Any]] = Field(default_factory=list)
    logs_ref: Optional[str] = None
    errors: list[str] = Field(default_factory=list)
