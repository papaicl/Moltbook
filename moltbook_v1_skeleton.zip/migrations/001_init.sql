-- Moltbook v1 initial schema
-- Executes automatically on postgres init (docker-entrypoint-initdb.d)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL,
  template TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id),
  prompt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned',
  estimated_cost_usd NUMERIC NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ NULL
);

CREATE TABLE IF NOT EXISTS task_steps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id UUID NOT NULL REFERENCES tasks(id),
  tool_name TEXT NOT NULL,
  step_order INTEGER NOT NULL,
  input_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  output_payload JSONB NULL,
  status TEXT NOT NULL DEFAULT 'planned',
  started_at TIMESTAMPTZ NULL,
  finished_at TIMESTAMPTZ NULL
);

CREATE TABLE IF NOT EXISTS artifacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id),
  task_id UUID NULL REFERENCES tasks(id),
  type TEXT NOT NULL,
  storage_path TEXT NULL,
  public_url TEXT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id UUID NOT NULL REFERENCES tasks(id),
  container_profile TEXT NOT NULL,
  runtime_sec INTEGER NULL,
  cpu_used DOUBLE PRECISION NULL,
  memory_mb INTEGER NULL,
  exit_code INTEGER NULL,
  logs_artifact_id UUID NULL REFERENCES artifacts(id)
);

CREATE TABLE IF NOT EXISTS tool_registry (
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  input_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
  output_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (name, version)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_task_steps_task_id ON task_steps(task_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_project_id ON artifacts(project_id);
CREATE INDEX IF NOT EXISTS gin_task_steps_input ON task_steps USING GIN (input_payload);
CREATE INDEX IF NOT EXISTS gin_task_steps_output ON task_steps USING GIN (output_payload);
CREATE INDEX IF NOT EXISTS gin_artifacts_meta ON artifacts USING GIN (metadata);

-- Seed tool registry (v1)
INSERT INTO tool_registry (name, version, active) VALUES
  ('create_project', '1.0', true),
  ('plan_task', '1.0', true),
  ('codegen_web_app', '1.0', true),
  ('build_test', '1.0', true),
  ('deploy_web', '1.0', true),
  ('report_generate', '1.0', true),
  ('data_job', '1.0', true),
  ('artifact_list', '1.0', true),
  ('artifact_download', '1.0', true),
  ('run_status', '1.0', true)
ON CONFLICT DO NOTHING;
