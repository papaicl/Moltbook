from __future__ import annotations

import re
import uuid
from typing import Any

from moltbook_shared.schemas import PlannedStep


WEB_HINTS = ("tetris", "app", "juego", "game", "react", "next", "web")
REPORT_HINTS = ("reporte", "report", "pdf", "docx", "informe", "executive summary")
DATA_HINTS = ("analiza", "analysis", "data", "dataset", "csv", "xlsx", "simul", "monte carlo")


def simple_plan(prompt: str) -> tuple[str, list[PlannedStep], float]:
    """Deterministic planner v1 (no LLM).

    Routes to:
    - web_app flow: codegen_web_app -> build_test -> deploy_web
    - report flow: report_generate
    - data flow: data_job
    """
    task_id = str(uuid.uuid4())
    p = prompt.lower()

    def has_any(tokens: tuple[str, ...]) -> bool:
        return any(t in p for t in tokens)

    steps: list[PlannedStep] = []
    est_cost = 0.5

    if has_any(WEB_HINTS):
        steps = [
            PlannedStep(step_id="1", tool="codegen_web_app", description="Generate web app repository", input_payload={
                "spec": {"framework": "react", "language": "typescript", "app_type": "game", "features": ["tetris_core", "scoreboard"]}
            }),
            PlannedStep(step_id="2", tool="build_test", description="Build and run smoke tests", input_payload={"run_tests": True}),
            PlannedStep(step_id="3", tool="deploy_web", description="Deploy to provider and return public URL", input_payload={"provider": "vercel"}),
        ]
        est_cost = 1.2
    elif has_any(REPORT_HINTS):
        steps = [
            PlannedStep(step_id="1", tool="report_generate", description="Generate premium report", input_payload={
                "title": "Technical Report",
                "sections": [{"heading": "Executive Summary", "content_instruction": "High-level summary"}],
                "format": "pdf",
            }),
        ]
        est_cost = 0.9
    elif has_any(DATA_HINTS):
        steps = [
            PlannedStep(step_id="1", tool="data_job", description="Run a sandboxed Python analysis job", input_payload={
                "script": "print('hello from data_job')",
                "parameters": {},
                "timeout_sec": 300,
            }),
        ]
        est_cost = 0.8
    else:
        # default: report
        steps = [
            PlannedStep(step_id="1", tool="report_generate", description="Generate premium report (default)", input_payload={
                "title": "Technical Note",
                "sections": [{"heading": "Summary", "content_instruction": "Concise summary"}],
                "format": "pdf",
            }),
        ]
        est_cost = 0.7

    return task_id, steps, est_cost
