from __future__ import annotations

import datetime as dt
import json
import uuid
from typing import Any, Generator

from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from moltbook_shared.schemas import PlanTaskIn, PlanTaskOut, ProjectCreate, ProjectOut, ExecuteTaskIn
from orchestrator.db import get_session, init_db
from orchestrator.mcp_client import MCPClient
from orchestrator.models import Artifact, Project, Task, TaskStep
from orchestrator.planner import simple_plan


app = FastAPI(title="Moltbook Orchestrator", version="0.1.0")


@app.on_event("startup")
def _startup() -> None:
    init_db()


@app.post("/projects", response_model=ProjectOut)
def create_project(payload: ProjectCreate, db: Session = Depends(get_session)) -> ProjectOut:
    existing = db.query(Project).filter(Project.name == payload.name).one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Project name already exists")
    p = Project(name=payload.name, type=payload.type, template=payload.template)
    db.add(p)
    db.commit()
    db.refresh(p)
    return ProjectOut(project_id=str(p.id), name=p.name, type=p.type, template=p.template)


@app.get("/projects/{project_id}", response_model=ProjectOut)
def get_project(project_id: str, db: Session = Depends(get_session)) -> ProjectOut:
    p = db.query(Project).filter(Project.id == uuid.UUID(project_id)).one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectOut(project_id=str(p.id), name=p.name, type=p.type, template=p.template)


@app.post("/tasks/plan", response_model=PlanTaskOut)
def plan_task(payload: PlanTaskIn, db: Session = Depends(get_session)) -> PlanTaskOut:
    project = db.query(Project).filter(Project.id == uuid.UUID(payload.project_id)).one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    task_id, steps, est_cost = simple_plan(payload.prompt)

    task = Task(id=uuid.UUID(task_id), project_id=project.id, prompt=payload.prompt, status="planned", estimated_cost_usd=est_cost)
    db.add(task)
    db.flush()

    for i, s in enumerate(steps, start=1):
        step = TaskStep(
            task_id=task.id,
            tool_name=s.tool,
            step_order=i,
            input_payload=s.input_payload,
            status="planned",
        )
        db.add(step)

    db.commit()

    return PlanTaskOut(task_id=task_id, steps=steps, estimated_cost_usd=float(est_cost))


@app.post("/tasks/execute")
def execute_task(payload: ExecuteTaskIn, db: Session = Depends(get_session)) -> dict[str, Any]:
    task = db.query(Task).filter(Task.id == uuid.UUID(payload.task_id)).one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.status = "running"
    db.commit()

    mcp = MCPClient()

    # Fetch steps ordered
    steps = db.query(TaskStep).filter(TaskStep.task_id == task.id).order_by(TaskStep.step_order).all()

    for step in steps:
        step.status = "running"
        step.started_at = dt.datetime.now(dt.timezone.utc)
        db.commit()

        try:
            tool_payload = dict(step.input_payload or {})
            # add common context
            tool_payload.setdefault("project_id", str(task.project_id))
            tool_payload.setdefault("task_id", str(task.id))

            result = mcp.call_tool(step.tool_name, tool_payload)
            step.output_payload = result
            step.status = "completed"
            step.finished_at = dt.datetime.now(dt.timezone.utc)

            # Persist any artifacts returned by MCP
            for a in result.get("artifact_refs", []):
                art = Artifact(
                    project_id=task.project_id,
                    task_id=task.id,
                    type=a.get("type", "unknown"),
                    storage_path=a.get("storage_path"),
                    public_url=a.get("public_url"),
                    metadata=a.get("metadata", {}),
                )
                db.add(art)

            db.commit()
        except Exception as e:
            step.output_payload = {"status": "failed", "errors": [str(e)]}
            step.status = "failed"
            step.finished_at = dt.datetime.now(dt.timezone.utc)
            task.status = "failed"
            task.completed_at = dt.datetime.now(dt.timezone.utc)
            db.commit()
            return {"status": "failed", "task_id": str(task.id), "error": str(e)}

    task.status = "completed"
    task.completed_at = dt.datetime.now(dt.timezone.utc)
    db.commit()
    return {"status": "completed", "task_id": str(task.id)}


@app.get("/tasks/{task_id}")
def get_task(task_id: str, db: Session = Depends(get_session)) -> dict[str, Any]:
    task = db.query(Task).filter(Task.id == uuid.UUID(task_id)).one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    steps = db.query(TaskStep).filter(TaskStep.task_id == task.id).order_by(TaskStep.step_order).all()
    return {
        "task_id": str(task.id),
        "project_id": str(task.project_id),
        "prompt": task.prompt,
        "status": task.status,
        "estimated_cost_usd": float(task.estimated_cost_usd) if task.estimated_cost_usd is not None else None,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
        "steps": [
            {
                "step_order": s.step_order,
                "tool_name": s.tool_name,
                "status": s.status,
                "started_at": s.started_at.isoformat() if s.started_at else None,
                "finished_at": s.finished_at.isoformat() if s.finished_at else None,
                "input_payload": s.input_payload,
                "output_payload": s.output_payload,
            }
            for s in steps
        ],
    }


@app.get("/tasks/{task_id}/stream")
def stream_task(task_id: str, db: Session = Depends(get_session)) -> StreamingResponse:
    # Minimal SSE: polls DB state a few times. Replace with real event bus later.
    task_uuid = uuid.UUID(task_id)

    def event_stream() -> Generator[bytes, None, None]:
        import time

        last = None
        for _ in range(60):  # ~60 seconds window
            t = db.query(Task).filter(Task.id == task_uuid).one_or_none()
            if not t:
                yield b"event: error\ndata: {"detail":"task not found"}\n\n"
                return
            payload = {"task_id": str(t.id), "status": t.status}
            if payload != last:
                yield f"data: {json.dumps(payload)}\n\n".encode("utf-8")
                last = payload
            if t.status in ("completed", "failed"):
                return
            time.sleep(1)

    return StreamingResponse(event_stream(), media_type="text/event-stream")
