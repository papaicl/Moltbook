from __future__ import annotations

from typing import Any
import requests

from orchestrator.config import get_settings


class MCPClient:
    def __init__(self) -> None:
        self._base = get_settings().mcp_base_url.rstrip("/")

    def call_tool(self, tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base}/tools/{tool_name}"
        r = requests.post(url, json=payload, timeout=60)
        r.raise_for_status()
        return r.json()
