from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    database_url: str
    mcp_base_url: str


def get_settings() -> Settings:
    database_url = os.getenv("DATABASE_URL", "postgresql+psycopg2://postgres:postgres@db:5432/moltbook")
    mcp_base_url = os.getenv("MCP_BASE_URL", "http://mcp:8001")
    return Settings(database_url=database_url, mcp_base_url=mcp_base_url)
