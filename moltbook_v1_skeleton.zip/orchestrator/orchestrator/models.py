from __future__ import annotations

import uuid
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    Numeric,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class Project(Base):
    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(Text, unique=True, nullable=False)
    type = Column(Text, nullable=False)
    template = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    tasks = relationship("Task", back_populates="project")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    prompt = Column(Text, nullable=False)
    status = Column(Text, nullable=False, default="planned")
    estimated_cost_usd = Column(Numeric, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    project = relationship("Project", back_populates="tasks")
    steps = relationship("TaskStep", back_populates="task", order_by="TaskStep.step_order")


class TaskStep(Base):
    __tablename__ = "task_steps"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"), nullable=False)
    tool_name = Column(Text, nullable=False)
    step_order = Column(Integer, nullable=False)
    input_payload = Column(JSONB, nullable=False, default=dict)
    output_payload = Column(JSONB, nullable=True)
    status = Column(Text, nullable=False, default="planned")
    started_at = Column(DateTime(timezone=True), nullable=True)
    finished_at = Column(DateTime(timezone=True), nullable=True)

    task = relationship("Task", back_populates="steps")


class Artifact(Base):
    __tablename__ = "artifacts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"), nullable=True)
    type = Column(Text, nullable=False)
    storage_path = Column(Text, nullable=True)
    public_url = Column(Text, nullable=True)
    metadata = Column(JSONB, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class Run(Base):
    __tablename__ = "runs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    task_id = Column(UUID(as_uuid=True), ForeignKey("tasks.id"), nullable=False)
    container_profile = Column(Text, nullable=False)
    runtime_sec = Column(Integer, nullable=True)
    cpu_used = Column(Float, nullable=True)
    memory_mb = Column(Integer, nullable=True)
    exit_code = Column(Integer, nullable=True)
    logs_artifact_id = Column(UUID(as_uuid=True), ForeignKey("artifacts.id"), nullable=True)


class ToolRegistry(Base):
    __tablename__ = "tool_registry"

    name = Column(Text, primary_key=True)
    version = Column(Text, primary_key=True)
    input_schema = Column(JSONB, nullable=False, default=dict)
    output_schema = Column(JSONB, nullable=False, default=dict)
    active = Column(Boolean, nullable=False, default=True)
