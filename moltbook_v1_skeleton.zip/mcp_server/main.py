from mcp_server.api import app
