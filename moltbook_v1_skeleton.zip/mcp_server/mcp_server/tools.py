from __future__ import annotations

import uuid
from typing import Any


TOOL_NAMES_V1 = [
    "create_project",
    "plan_task",
    "codegen_web_app",
    "build_test",
    "deploy_web",
    "report_generate",
    "data_job",
    "artifact_list",
    "artifact_download",
    "run_status",
]


def list_tools() -> list[dict[str, Any]]:
    return [{"name": n, "version": "1.0", "active": True} for n in TOOL_NAMES_V1]


def execute_tool(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Stub implementations (deterministic). Replace with real tool logic."""
    if tool_name not in TOOL_NAMES_V1:
        return {"status": "failed", "errors": [f"Unknown tool: {tool_name}"], "artifact_refs": []}

    # Basic simulated outputs per tool type
    if tool_name == "deploy_web":
        # deterministic fake url
        app_id = str(uuid.uuid4())[:8]
        return {
            "status": "success",
            "output_payload": {"public_url": f"https://example-{app_id}.app", "deployment_id": app_id, "status": "live"},
            "artifact_refs": [{"type": "public_url", "public_url": f"https://example-{app_id}.app", "metadata": {"provider": payload.get("provider", "vercel")}}],
            "errors": [],
        }

    if tool_name == "report_generate":
        art_id = str(uuid.uuid4())
        return {
            "status": "success",
            "output_payload": {"artifact_id": art_id, "download_url": f"s3://artifacts/{art_id}.pdf", "pages": 12},
            "artifact_refs": [{"type": "pdf", "storage_path": f"artifacts/{art_id}.pdf", "metadata": {"title": payload.get("title", "Report")}}],
            "errors": [],
        }

    if tool_name == "codegen_web_app":
        art_id = str(uuid.uuid4())
        return {
            "status": "success",
            "output_payload": {"repo_path": f"/work/{art_id}", "files_generated": 28},
            "artifact_refs": [{"type": "zip", "storage_path": f"artifacts/{art_id}.zip", "metadata": {"kind": "repo_bundle"}}],
            "errors": [],
        }

    if tool_name == "build_test":
        return {
            "status": "success",
            "output_payload": {"build_status": "success", "test_results": {"passed": 5, "failed": 0}},
            "artifact_refs": [{"type": "logs", "storage_path": "logs/build_test.log", "metadata": {}}],
            "errors": [],
        }

    if tool_name == "data_job":
        art_id = str(uuid.uuid4())
        return {
            "status": "success",
            "output_payload": {"runtime_sec": 3, "status": "completed"},
            "artifact_refs": [{"type": "csv", "storage_path": f"artifacts/{art_id}.csv", "metadata": {"rows": 10}}],
            "errors": [],
        }

    # create_project, plan_task, artifact_list, artifact_download, run_status are handled by orchestrator in this skeleton
    return {"status": "success", "output_payload": {"note": "stub"}, "artifact_refs": [], "errors": []}
