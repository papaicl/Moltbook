from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from mcp_server.tools import execute_tool, list_tools


class ToolPayload(BaseModel):
    payload: dict


app = FastAPI(title="Moltbook MCP Server", version="0.1.0")


@app.get("/tools")
def tools() -> dict:
    return {"tools": list_tools()}


@app.post("/tools/{tool_name}")
def call_tool(tool_name: str, body: dict) -> dict:
    # body is the tool payload
    result = execute_tool(tool_name, body)
    if result.get("status") == "failed":
        raise HTTPException(status_code=400, detail=result.get("errors", ["tool failed"]))
    return result
