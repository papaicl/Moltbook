from __future__ import annotations
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    redis_url: str

def get_settings() -> Settings:
    return Settings(redis_url=os.getenv("REDIS_URL", "redis://redis:6379/0"))
