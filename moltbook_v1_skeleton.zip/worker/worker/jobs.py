from __future__ import annotations

import time
from typing import Any

def sandbox_job(payload: dict[str, Any]) -> dict[str, Any]:
    # Placeholder job implementation
    time.sleep(1)
    return {"status": "completed", "echo": payload}
