# Moltbook Mobile Internal Platform — v1 Skeleton

This repository is an **advanced (non-final) skeleton** for a mobile-first "Moltbook-like" system:
- **Orchestrator** (FastAPI): task planning/execution coordinator + SSE streaming
- **MCP Server** (FastAPI): tool registry + tool gateway (contracts)
- **Worker** (RQ/Redis): sandbox job runner placeholder
- **Infra**: Postgres + Redis + MinIO + services via Docker Compose

> Notes:
> - This is a working scaffold intended to be extended.
> - Tool implementations are **stubbed** (they return deterministic placeholders).
> - Database schema is provided as a single SQL migration: `migrations/001_init.sql`.

## Quickstart (local)

### 1) Requirements
- Docker + Docker Compose

### 2) Run
```bash
cd infra
docker compose up --build
```

### 3) Service URLs
- Orchestrator Swagger: http://localhost:8000/docs
- MCP Server Swagger: http://localhost:8001/docs
- MinIO Console: http://localhost:9001  (user/pass: minioadmin/minioadmin)

### 4) Env
Defaults are provided in `infra/.env`. Adjust as needed.

## What is implemented

### Database
- Tables: projects, tasks, task_steps, artifacts, runs, tool_registry
- Indexes (including JSONB GIN)
- Tool registry seed (v1 tool names)

### Orchestrator (FastAPI)
- POST `/projects`
- GET  `/projects/{project_id}`
- POST `/tasks/plan`
- POST `/tasks/execute` (sequential execution: calls MCP stubs, persists steps/artifacts)
- GET  `/tasks/{task_id}`
- GET  `/tasks/{task_id}/stream` (SSE: emits state transitions; minimal)

### MCP Server (FastAPI)
- GET  `/tools`
- POST `/tools/{tool_name}` (stub tool execution)

### Worker (RQ)
- Minimal wiring; sandbox profiles described, not enforced yet.

## Next steps (recommended)
1) Implement real tools:
   - codegen_web_app, build_test, deploy_web, report_generate, data_job
2) Enforce policy engine (cost/time/memory/network allowlists)
3) Replace stub SSE with log streaming from runner
4) Add PWA client

